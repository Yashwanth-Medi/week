package com.infinite.Control;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

@Controller
public class LoginControl {
	@RequestMapping("/login")
	public String registor(HttpServletRequest request, HttpServletResponse response) {
		java.sql.Connection con = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			DataSource dataSource = Hikari.getDataSource();
			con = dataSource.getConnection();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
	}

}
