package com.infinite.register;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class HekariHelp {

	private static DataSource datasource = null;

	public static DataSource getDataSource() {
		if (datasource == null) {
			HikariConfig config = new HikariConfig();
			config.setJdbcUrl("jdbc:mysql://localhost:3306/training");//url of database
			config.setUsername("root");//user name
			config.setPassword("mysql123@");//password of databse
			config.setMaximumPoolSize(10);
			config.setAutoCommit(true);//setting commit to save data
			config.addDataSourceProperty("cachePrepStmts ", "true");
			config.addDataSourceProperty("prepStmtCacheSize", "250");
			config.addDataSourceProperty("prepStmtCacheSqlLimit", "2045");
			datasource = new HikariDataSource(config);
		}
		return datasource;
	}
}
